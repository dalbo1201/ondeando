#!/bin/bash
./blogger_to_jekyll https://www.seublog.com.br
