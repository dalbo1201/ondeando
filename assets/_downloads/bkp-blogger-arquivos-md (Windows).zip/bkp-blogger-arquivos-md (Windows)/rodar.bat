@echo off
blogger_to_jekyll.exe https://HISTORIASPARALER.BLOG.BR
pause